-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2017-08-08 14:45:43
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sqlinject`
--

-- --------------------------------------------------------

--
-- 表的结构 `classes`
--

CREATE TABLE IF NOT EXISTS `classes` (
  `les_id` text NOT NULL,
  `les_name` text NOT NULL,
  `classroom` text NOT NULL,
  `time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `classes`
--

INSERT INTO `classes` (`les_id`, `les_name`, `classroom`, `time`) VALUES
('1', 'Math', '3301', '10:30'),
('2', 'English', '3302', '11:30'),
('3', 'Chinese', '3303', '12:30'),
('4', 'physics', '3304', '13:30'),
('5', 'chemistry', '3305', '14:30'),
('6', 'philosophy', '3306', '15:30'),
('7', 'computer', '3307', '16:30');

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `First Name` text NOT NULL,
  `Last Name` text NOT NULL,
  `Email address` text NOT NULL,
  `Password` text NOT NULL,
  `class` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`First Name`, `Last Name`, `Email address`, `Password`, `class`) VALUES
('1', '1', 'admin', 'admin', '-'),
('1', '1', 'admin', 'admin', '-'),
('1', '1', 'admin', 'admin', '-'),
('2', '2', '2', 'admin', '-'),
('2', '2', '1', 'admin', '1'),
('2', '2', '3', 'admin', '1'),
('2', '2', '4', 'admin', '1'),
('2', '2', '5', 'admin', '1'),
('2', '2', '66', 'admin', '1'),
('2', '2', '664', 'admin', '1'),
('1', '1', '33333', 'admin', '2'),
('1', '1', '3333333', 'admin', '2'),
('123', '123', '1111', 'admin', '1'),
('123', '123', '23', 'admin', '1'),
('123', '123', '22333', 'admin', '5'),
('34', '34', 'admin43', 'admin', '4'),
('qwe', 'qwe', 'adminqwe', 'admin', '2'),
('123', '13', 'admin2', 'admin', '5'),
('1', '2', '123123', '123', '1.1800655027308849e57'),
('123', '324234', 'admin234234234', 'admin', '0 union select 1,2,3,4,5'),
('234', '234234', 'admin234234', 'admin', '0 union select 1,2,3,4,5'),
('1', '2', '12dsddfsfdsf3123', '123', '0 union select 1,2,3,4,5'),
('1', '2', '12dasdsddfsfdsf3123', '123', '0 union select 1,2,3,4,5'),
('1', '2', '12asdasddasdsddfsfdsf3123', '123', '0 union select 1,2,3,4'),
('hacker asdad', 'asd', 'yz', 'adminasd', '2');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
